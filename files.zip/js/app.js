import { db } from './firebase-init.js';
import { ref, push, set, onValue } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";

const searchInput = document.getElementById('search-input');
const searchBtn = document.getElementById('search-btn');
const subscribeForm = document.getElementById('subscribe-form');
const emailInput = document.getElementById('email-input');
const subscribeMsg = document.getElementById('subscribe-msg');
const cardsContainer = document.getElementById('cards');
const mediaList = document.getElementById('media-list');

searchBtn.addEventListener('click', () => {
  const val = searchInput.value.trim();
  if (val === 'admin-end') {
    window.location.href = `admin.html?admin_key=${encodeURIComponent(val)}`;
  } else {
    alert('Search is currently only used to enter admin key. Try "admin-end" if you are admin.');
  }
});

// Subscribe
subscribeForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = emailInput.value.trim();
  if (!email) return;
  const subsRef = ref(db, 'subscribers');
  const newSubRef = push(subsRef);
  await set(newSubRef, {
    email,
    createdAt: Date.now()
  });
  subscribeMsg.textContent = 'Thanks for subscribing!';
  emailInput.value = '';
  setTimeout(()=>subscribeMsg.textContent='','4000');
});

// Load cards
const cardsRef = ref(db, 'content/cards');
onValue(cardsRef, (snapshot) => {
  cardsContainer.innerHTML = '';
  const data = snapshot.val();
  if (!data) {
    cardsContainer.innerHTML = '<p>No motivational texts yet.</p>';
    return;
  }
  Object.entries(data).forEach(([id, card]) => {
    const div = document.createElement('div');
    div.className = 'card';
    div.innerHTML = `<h3>${escapeHtml(card.title||'')}</h3><p>${escapeHtml(card.text||'')}</p>`;
    cardsContainer.appendChild(div);
  });
});

// Media: not loaded from DB. Show informational message to visitors.
if (mediaList) {
  mediaList.innerHTML = '<p>Media is managed by the admin via public URLs and is not stored in the Realtime Database.</p>';
}

// Utility
function escapeHtml(str){
  if(!str) return '';
  return String(str)
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/\"/g,'&quot;')
    .replace(/'/g,'&#039;');
}