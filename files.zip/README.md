```markdown
# Spiritual Science — Web App (HTML/CSS/JS + Firebase)

This version (update 2) changes how media is handled:
- Subscriber emails are still stored in the Firebase Realtime Database.
- Motivational text cards and newsletters are still stored in the Realtime Database.
- Media (images, audio, video) are NOT stored in the Realtime Database. Admins can enter public media URLs in the admin panel for preview only; these URLs are NOT saved to the database by design.

Why: You requested that files (media) not be written to the Realtime Database. Storing URLs client-side only prevents the DB from growing with large media payloads.

Notes:
- Admin previews of media URLs exist only for the admin session and are not persisted.
- If you later want to persist media metadata (e.g., URLs) in the DB, I can add an option to save them.
- Ensure your Realtime Database rules allow the admin and subscribers to perform the intended reads/writes.
```